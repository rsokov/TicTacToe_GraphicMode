package ru.graphictictactoe.app;

public class Main {

    public static void main(String[] args) {

        Game gameInstance = new Game();
        gameInstance.initGame();
    }
}
